# ANCHORING
Studies the effect of anchoring in social context when making a decision under a high cognitive load enviorenment.

## Instructions
Install otree  
~> pip install otree  
change directory to current folder(ANCHORING)  
~> otree devserver
